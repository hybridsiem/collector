1. Make mkptnr command executable; chmod +x mkptnr
2. Run ./mkptnr [token_file]; where token_file has same name as your machineID
